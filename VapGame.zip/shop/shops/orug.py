import os


def shop_orug(username, inventory, setings):
    otv = input('''Выберите что купить:
1) 200 монет - 1 меч
2) 250 монет - 1 топор
3) 350 монет - 1 лук
4) 5 монет - 1 стрелы
5) 3000 монет - 1 броня
6) 150 монет - 1 кирка
7) 150 монет - 1 лопата
8) 150 монет - 1 мотыга
''')
    os.system('cls||clear')
    otv2 = int(input(f'В каком кольчестве вы хотите купить товар № {otv}.'))
    os.system('cls||clear')
    if otv == '1' and otv2*200 <= setings.BALANCE:
        inventory.name['SWORD'] = inventory.name['SWORD'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 200)
        print(inventory.name['SWORD'])
        print(setings.BALANCE)
    elif otv == '2' and otv2*250 <= setings.BALANCE:
        inventory.name['AXE'] = inventory.name['AXE'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 250)
        print(inventory.name['AXE'])
        print(setings.BALANCE)
    elif otv == '3' and otv2*350 <= setings.BALANCE:
        inventory.name['ONION'] = inventory.name['ONION'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 350)
        print(inventory.name['ONION'])
        print(setings.BALANCE)
    elif otv == '4' and otv2*5 <= setings.BALANCE:
        inventory.name['SCTRELA'] = inventory.name['SCTRELA'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 5)
        print(inventory.name['SCTRELA'])
        print(setings.BALANCE)
    elif otv == '5' and otv2*3000 <= setings.BALANCE:
        inventory.name['ARMOR'] = inventory.name['ARMOR'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 3000)
        print(inventory.name['ARMOR'])
        print(setings.BALANCE)
    elif otv == '6' and otv2*150 <= setings.BALANCE:
        inventory.name['PICK'] = inventory.name['PICK'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 150)
        print(inventory.name['PICK'])
        print(setings.BALANCE)
    elif otv == '7' and otv2*150 <= setings.BALANCE:
        inventory.name['SHOVEL'] = inventory.name['SHOVEL'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 150)
        print(inventory.name['SHOVEL'])
        print(setings.BALANCE)
    elif otv == '8' and otv2*150 <= setings.BALANCE:
        inventory.name['HOE'] = inventory.name['HOE'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 150)
        print(inventory.name['HOE'])
        print(setings.BALANCE)

    # Проверка
    else:
        print('ОШИБКА')
