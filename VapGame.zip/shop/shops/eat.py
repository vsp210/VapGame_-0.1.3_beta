def shop_eat(username, inventory, setings):
    import os
    os.system('cls||clear')
    otv = input('''Выберите что купить:
1) 20 монет - 10 еды
''')
    os.system('cls||clear')
    otv2 = int(input(f'В каком кольчестве вы хотите купить товар № {otv}.'))
    if otv == '1' and otv2*2 <= setings.BALANCE:
        inventory.name['FOOD'] = inventory.name['FOOD'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 2)
        print(inventory.name['FOOD'])
        print(setings.BALANCE)
        os.system('cls||clear')


    # Проверка
    else:
        os.system('cls||clear')
        print('ОШИБКА')
