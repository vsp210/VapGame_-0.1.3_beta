import os


def shop_hause(username, inventory, setings):
    otv = input('''Выберите что купить:
1) 200 монет - 10 досок
2) 100 монет - 10 палки
3) 250 монет - 10 булыжника
4) 400 монет - 10 стекла
5) 600 монет - 10 освешение
6) 2500 монет - 10 мебель
''')
    os.system('cls||clear')
    otv2 = int(input(f'В каком кольчестве вы хотите купить товар № {otv}.'))
    if otv == '1' and otv2*20 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['BOARD'] = inventory.name['BOARD'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 20)
        # print(inventory.name['BOARD'])
        # print(setings.BALANCE)
    elif otv == '2' and otv2*10 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['STICKS'] = inventory.name['STICKS'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 10)
        # print(inventory.name['STICKS'])
        # print(setings.BALANCE)
    elif otv == '3' and otv2*25 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['STONE'] = inventory.name['STONE'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 25)
        # print(inventory.name['STONE'])
        # print(setings.BALANCE)
    elif otv == '4' and otv2*40 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['GLASS'] = inventory.name['GLASS'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 40)
        # print(inventory.name['GLASS'])
        # print(setings.BALANCE)
    elif otv == '5' and otv2*60 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['LIGHTING'] = inventory.name['LIGHTING'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 60)
        # print(inventory.name['LIGHTING'])
        # print(setings.BALANCE)
    elif otv == '6' and otv2*250 <= setings.BALANCE:
        os.system('cls||clear')
        inventory.name['FURNITURE'] = inventory.name['FURNITURE'] + otv2
        setings.BALANCE = setings.BALANCE - (otv2 * 250)
        # print(inventory.name['FURNITURE'])
        # print(setings.BALANCE)

    # Проверка
    else:
        print('ОШИБКА')
