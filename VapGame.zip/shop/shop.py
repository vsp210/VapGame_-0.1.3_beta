import os
from shop.shops import hause, eat, orug
from decrease import decrease

def main_shop(username, city, inventory, setings):
    decrease.decrease1(f"Привет {username}, я Шопер владею кучей магазинов в городе {city}.\nХочешь купить что-то или какие-то вопросы?\n", 0.00005)
    otv = input('Выберите:\n1) Купить вещи для дома.\n2) Купить еды.\n3) Купить оружие или инструменты.\n4) Спросить как построить дом\n')
    if otv == '1':
        os.system('cls||clear')
        hause.shop_hause(username, inventory, setings)
    elif otv == '2':
        os.system('cls||clear')
        eat.shop_eat(username, inventory, setings)
    elif otv == '3':
        os.system('cls||clear')
        orug.shop_orug(username, inventory, setings)
    elif otv == '4':
        os.system('cls||clear')
        print('Чтобы сделать дом нужно: \n50 досок\n50 камня\n50 кирпича\n10 стекла\n1 мебель\n5 освещения')


# main_shop('vsp44', 'Щёкино', )
