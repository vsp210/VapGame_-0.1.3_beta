name = {
    'BOARD' : 0,  # ДОСКА
    'STONE' : 0, # КАМЕНЬ
    'BRICK' : 0, # КИРПИЧ
    'GLASS' : 0, # СТЕКЛО
    'STICKS' : 0, # ПАЛКИ
    'FURNITURE' : 0, # МЕБЕЛЬ
    'LIGHTING' : 0, # ОСВЕЩЕНИЕ
    'LEATHER' : 0, # КОЖА
    'FOOD' : 0, # ЕДА
    'PICK' : 0, # КИРКА
    'AXE' : 0, # ТОПОР
    'SWORD' : 0, # МЕЧ
    'SHOVEL' : 0, # ЛОПАТА
    'HOE' : 0, # МОТЫГА
    'ARMOR' : 0, # БРОНЯ
    'ONION' : 0, # ЛУК
    'SCTRELA' : 0 # СТРЕЛА
}
