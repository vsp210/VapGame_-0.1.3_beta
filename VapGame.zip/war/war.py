from shop.shops import orug
from decrease import decrease
from .wars import speak
import time
def main_war(username, city, inventory, setings):
    decrease.decrease1(f'Здравия желаю боец - {username}.\nМолодец, что пошол на войну, нам как раз нужны войны\n', 0.1)
    otv = input('Выбирай куда пойдёшь:\n1) Пехота\n2) Я не буду служить, я ухожу!\n')
    if otv == '1':
        decrease.decrease1('Иди купи оружие\n', 0.15)
        time.sleep(1)
        orug.shop_orug(username, inventory, setings)
    elif otv == '2':
        decrease.decrease1('Тогда зачем ты сюда пришол!!!\n', 0.025)
        otv = input('Выберите:\n1) Вы кто такие чтоб кричать на меня\n2) Я просто прогуливаюсь\n')
        if otv == '1':
            decrease.decrease1('Ты хотябы знаешь кому перечешь?\n', 0.1)
            speak.general(username, city, inventory, setings)
