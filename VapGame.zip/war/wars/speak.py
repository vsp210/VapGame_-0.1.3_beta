import os
from decrease import decrease
from random import randint

def general(username, city, inventory, setings):
    otv = input('Выберите:\n1) Какой то старик передомной\n2) Ой Извените, я вас не узнал вы - Генерал\n')
    if otv == '1':
        os.system('cls||clear')
        decrease.decrease1('Я генерал, Карабов, а за то, что мне грубил так отправляю тебя в тюрьму - Газер\n', 0.1)
        setings.KARMA -= randint(5, 10)
        print(f'Карма = {setings.KARMA}')
    elif otv == '2':
        os.system('cls||clear')
        decrease.decrease1('Как видишь, да.\nДавно не видел таких смельчаков.\nИди ты свободен.\n', 0.1)
        input('Выберите:\n1) Ещё раз простите досведания\n')
        decrease.decrease1('Ещё раз простите досведания\n', 0.1)
