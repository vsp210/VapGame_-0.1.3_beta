import time

def decrease1(txt, times):
    for i in txt:  # этот цикл будет брать по 1 буковке из тхт
        time.sleep(times)
        print(i, end='', flush=True)
