import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
def mail(text, user, name):
    msg = MIMEMultipart()
    msg['From'] = 'vapgame@yandex.ru'
    # msg['To'] = 'psv449@yandex.ru'
    msg['To'] = user
    msg['Subject'] = name
    msg.attach(MIMEText(text))
    try:
        mailserver = smtplib.SMTP_SSL('smtp.yandex.ru',465)
        mailserver.set_debuglevel(True)
        mailserver.login('vapgame@yandex.ru', 'osrquwpvcjeyddhl')
        mailserver.sendmail('vapgame@yandex.ru', user, msg.as_string())
        mailserver.quit()
        import os
        os.system('cls||clear')
        print("Письмо успешно отправлено")
    except smtplib.SMTPException:
        print("Ошибка: Невозможно отправить сообщение")

mail('test', 'vsp44@yandex.ru', 'test')
