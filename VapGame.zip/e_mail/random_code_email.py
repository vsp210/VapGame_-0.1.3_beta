from random import randint
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
def mail(text, user, name, password = None):
    msg = MIMEMultipart()
    msg['From'] = 'vapgame@yandex.ru'
    # msg['To'] = 'psv449@yandex.ru'
    msg['To'] = user
    msg['Subject'] = name
    msg.attach(MIMEText(text))
    try:
        mailserver = smtplib.SMTP_SSL('smtp.yandex.ru',465)
        mailserver.set_debuglevel(True)
        mailserver.login('vapgame@yandex.ru', 'osrquwpvcjeyddhl')
        mailserver.sendmail('vapgame@yandex.ru', user, msg.as_string())
        mailserver.quit()
        os.system('cls||clear')
        print("Письмо успешно отправлено")
    except smtplib.SMTPException:
        print("Ошибка: Невозможно отправить сообщение")

    code = str(input())
    if code == password:
        return "успех"
    else:
        return "НЕ УСПЕХ"
